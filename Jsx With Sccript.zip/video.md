# NetOptim — 2-Minute Video Pitch: Production Plan & Shooting Script
**Deliverable:** Round-1 video pitch, max 2 minutes, all 4 members participating.
**Companion deliverable:** 2 slides (separate — this document covers the video only).
**Status:** plan agreed; tool build (`NetOptim_v7_demo.jsx`) in progress to support it.

---

## 1. Structure agreed

| Segment | Time | Speaker | Job |
|---|---|---|---|
| **A · Problem & proposed solution** | 0:00 – 0:30 | M1 | Set up the pain, state the idea. No tool on screen yet. |
| **B · The tool, part 1 — data + AI perception + reasoning** | 0:30 – 1:05 | M2 | Where the AI *sits*, how a planner talks to it. |
| **C · The tool, part 2 — decision + explanation** | 1:05 – 1:40 | M3 | The hero moment: machine-found exit, defensible rationale. |
| **D · Value, roadmap, wrap** | 1:40 – 2:00 | M4 | Impact number, what's next, sign-off. |

**Total 120s with ~5s of breathing room.** Tool is on screen for **70 seconds** (segments B + C) — this is the emphasis you asked for.

Pacing budget at presentation rate (~2.5 words/sec):
- A ≈ 75 words · B ≈ 85 words · C ≈ 85 words · D ≈ 50 words

---

## 2. Shooting script

### A · 0:00 – 0:30 · M1 — Problem & solution *(no tool on screen)*

> "A consumer-goods network: five distribution centres, six million units a year, thirteen demand regions. Two DCs are at a hundred percent. One sits at twenty-five. One region is served from seventeen hundred kilometres away.
>
> The planning team knows all of this. What they don't have is a way to ask *what if* and get an answer the same day — today that's a four-week consulting study in a spreadsheet nobody can audit.
>
> So we built **NetOptim** — an AI copilot that turns network design from a quarterly study into a live conversation."

**On screen:** title card → one static network diagram with the three pain points annotated. Hold on the annotated map as the last line lands, then cut to the tool.

---

### B · 0:30 – 1:05 · M2 — Data, perception, reasoning *(tool on screen)*

**Beat 1 — the data layer (0:30–0:42)**
> "It starts with the network you already have — sites, capacities, fixed costs, handling rates, demand by region, and lane-level freight. Upload a CSV or edit it in place. No IDs, no modelling language."

*On screen:* Tab 1. Scroll the warehouse table, flash the lane-cost matrix, hover the CSV upload panel. **Don't click into anything** — this is texture, 12 seconds.

**Beat 2 — AI perception (0:42–0:53)**
> "The moment it loads, the copilot reads the network itself and reports back: two DCs capacity-bound, one under-used at twenty-five percent, and the longest haul in the system flagged as a cost and service hotspot. Nobody asked it to look."

*On screen:* Cut to Tab 2. The auto-scan card is already in the copilot feed. **PERCEIVE** lights up on the agentic strip. Let the diagnostic card fill the frame briefly.

**Beat 3 — AI reasoning, natural language (0:53–1:05)**
> "Then you just ask. 'Increase demand at D9 by thirty percent.' It parses the intent, re-solves the whole network, and shows you exactly what moved — service down two points, cost up one-point-two crore."

*On screen:* Type the query live into the copilot. **REASON** lights up. The before→after KPI card posts. Map flows visibly re-route.

---

### C · 1:05 – 1:40 · M3 — Decision & explanation *(tool on screen)*

**Beat 4 — the optimiser (1:05–1:18)**
> "Now the decision. Converge to optimum. It evaluates every open-close combination across all sites — two hundred and fifty-five configurations — right-sizes capacity where sites overload, and prices the transition."

*On screen:* Click **Converge to optimum**. **ACT** lights up, progress counter runs. Map animates into the new topology.

**Beat 5 — the hero moment (1:18–1:31)**
> "And it doesn't just add. It recommends **exiting WH 4** — the under-used site — while opening two new ones. Seven crore a year saved, service up four points. That closure is a move the machine found on its own; nobody suggested it."

*On screen:* WH 4 renders in **red dashed with an ✕ EXITED tag** — unmistakable. Recommendation card lands with the metric grid. Hold here — **this is the most important 13 seconds of the video.**

**Beat 6 — defensibility (1:31–1:40)**
> "And every recommendation comes with its reasoning and its watch-outs — including that a closure only saves its full fixed cost at lease break. It argues its case like an analyst, not a black box."

*On screen:* Scroll the recommendation card to show **Why** and **Watch-outs**. **EXPLAIN** lights up.

---

### D · 1:40 – 2:00 · M4 — Value, roadmap, wrap

> "Every configuration tested is logged automatically — drag the assumptions and watch whether the winner holds. That's how a planner earns the confidence to sign.
>
> Twelve to fourteen percent of network cost, and a decision cycle that goes from weeks to minutes. Next: swapping our rule-based parser for a full LLM, a MILP solver underneath, and live telematics.
>
> NetOptim. Team [name]. Thank you."

*On screen:* Tab 3, sliders wiggling, ★ staying on the same row. **LEARN** lights up. Then the roadmap card. Cut to team card with all four faces.

---

## 3. "Where and how are we using AI?" — the explicit answer

This is the question judges *will* ask. The tool now answers it visually via the **agentic loop strip**, which lights up stage-by-stage as the demo runs. Each stage maps to something real:

| Stage | What it does | Honest status |
|---|---|---|
| **PERCEIVE** | Auto-diagnoses hotspots on load — over/under-used nodes, longest haul, cost concentration | Rule-based heuristics on solved KPIs |
| **REASON** | Parses natural-language what-ifs into simulation parameters | **Rule-based parser in demo; LLM in production** — say this out loud |
| **ACT** | Enumerative search over configurations with priced right-sizing | Real math, deterministic, verified by test harness |
| **EXPLAIN** | Generates rationale + watch-outs tied to the actual numbers that drove the result | Templated generation from solver output |
| **LEARN** | Auto-logs every tested configuration for comparison and robustness testing | Deterministic, dedup by signature |

**The framing to use:** *"The solver is real math. The AI is the layer that decides what to solve, explains why, and remembers what it tried."* Position it as **solver + reasoning copilot** — that's the defensible next-gen story, and it's honest.

**Do not** claim the NL parser is an LLM. Say it's a drop-in placeholder. Volunteering the limitation converts a weakness into credibility, and a judge who discovers it themselves will discount everything else you said.

---

## 4. Functionality coverage — what gets seen vs said

| Feature | On screen | Narrated | Why |
|---|---|---|---|
| Data tables, CSV upload | ✅ Beat 1 | Brief mention | Proves it takes real client data |
| Lane-cost matrix | ✅ Beat 1 (flash) | ❌ | Depth as texture; costs no words |
| Auto network scan | ✅ Beat 2 | ✅ | Core "perceive" evidence |
| Natural-language what-if | ✅ Beat 3 | ✅ | Core "reason" evidence |
| Live re-solve + KPI deltas | ✅ Beat 3 | ✅ | Proves the engine is live |
| Optimiser + right-sizing | ✅ Beat 4 | ✅ | Core "act" evidence |
| **Machine-found site exit** | ✅ Beat 5 | ✅ | **The hero. Answers the brief's "resize or exit" question.** |
| Rationale + watch-outs | ✅ Beat 6 | ✅ | Core "explain" evidence — defensibility |
| Compare + sensitivity | ✅ Beat 7 | ✅ | Robustness = board confidence |
| Carbon pricing | ✅ (visible in KPI bar) | ❌ | Mention only if asked; no time |
| Capacity slider / lock-open | ⚠️ visible, not used | ❌ | **Q&A ammunition** — see §6 |
| Roadmap panel | ✅ Beat 7 | ✅ (one line) | Covers "future thoughts" ask |

---

## 5. Tool changes being built to support this script

Building as **`NetOptim_v7_demo.jsx`** — v6 stays untouched.

**Video legibility (the whole UI is being restyled for compression):**
- Type scale up ~20%; no on-camera text below 12px
- Muted text `#777 → #8f8f8f`, dim `#5a5a5a → #7a7a7a`, borders `#1e1e1e → #262626` — current contrast dies under H.264 and on a projector
- KPI values enlarged; deltas count up on change so the saving *arrives* rather than just existing

**Beat support:**
- **Agentic loop strip** — the signature element; lights up PERCEIVE → REASON → ACT → EXPLAIN → LEARN as the demo runs. Directly answers "where's the AI?" without spending narration on it.
- **Exited-site visual** — red dashed ring + ✕ EXITED tag, distinct from an unopened candidate. *Without this, Beat 5 is invisible on video.*
- **Motion** — 450ms transitions on flow lines and node radii, so Converge reads as the system solving rather than a jump cut
- **Progress state on Converge** — the button counts configurations instead of freezing
- **Demo mode** — an on-screen teleprompter that steps through the seven beats with the narration line and a Next control, so four people can choreograph the 70-second segment
- **Roadmap card** — makes the "future thoughts" ask visible rather than only spoken

**Demo-safety engine fixes (from `review_2.md`):**
- **E4** optimiser no longer inherits manual capacity overrides — currently a stray slider drag before Converge silently reports a number ₹3cr worse than optimal, live on camera
- **E1** carbon objective made cost-aware — currently Service, Balanced and Carbon all return the identical network, which looks broken if anyone clicks through them
- **E3** service tiebreak on cost, not distance — stops it paying ₹1.18cr for zero service gain
- **E2** balanced objective normalised over the non-dominated set — restores discrimination lost when H1 admitted absurd configs

---

## 6. Q&A ammunition (not in the video, ready if asked)

| Likely question | Answer | Click to prove it |
|---|---|---|
| "Is this actually AI or just a solver?" | Solver + reasoning copilot; the loop strip shows the split | Point at the agentic strip |
| "What if that DC can't close mid-lease?" | Per-site lock excludes it from the closure search | Lock WH 4, re-converge |
| "Does a carbon tax change the answer?" | Yes — above ~₹1000/t the optimum shifts | Drag the carbon slider |
| "Can it take our data?" | CSV in, templates provided, validated with row-level errors | Tab 1 upload panel |
| "How do you know it's robust?" | Every config logged; drag assumptions, watch the ★ | Tab 3 sliders |
| "Is it optimal?" | Enumerative + heuristic assignment, near-optimal for this structure — MILP is the production path | Say it plainly |

---

## 7. Recording notes

- **Record at 1920×1080**, not scaled — the UI is being tuned for it. Avoid 1024-wide windows; the KPI bar gets tight.
- **Use demo mode** to drive the tool segment. One person drives, speakers narrate over it.
- **Reset before every take** (Reset button, then re-converge). Do **not** touch the capacity slider before Converge in a take.
- **Record the tool segment silently first**, then lay narration over it. Trying to talk and drive simultaneously in 70 seconds will cost you retakes.
- **Hold on Beat 5 for a full 3 seconds** before cutting. It's the moment the whole pitch rests on.
- Faces: brief on-camera handoffs at segment boundaries satisfy "all 4 members participating" without eating tool time.

---

## 8. Open items

- [ ] Confirm whether the submission accepts a link to the live prototype — if yes, polish on non-demo surfaces starts paying off and §4's "texture only" calls loosen
- [ ] Final value figure for D: engine now yields **₹7.03cr (~14%)**, up from the ₹5.85cr in older docs — confirm which number goes on Slide 2 so video and deck agree
- [ ] Team name / sign-off card
- [ ] Decide if carbon gets a spoken line (currently cut for time)

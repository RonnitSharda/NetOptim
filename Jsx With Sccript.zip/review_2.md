# NetOptim v6 — QA & UI Review (Review #2)
**Scope:** `NetOptim_v6.jsx` (1,277 lines) + `NetOptim_Project_Documentation_v6.md`, re-reviewed against Case 16 and against the v5 findings in `review.md`.
**Method:** the v6 engine was extracted verbatim into a Node harness and executed — every claim below marked ✅/❌ was run, not eyeballed. UI findings are code-read against the rendered layout.

---

## 0. Verdict

**H1–H4 all landed, and H1 works impressively well** — the optimiser now finds the WH 4 exit on its own (−₹7.03cr vs baseline), which is exactly the "machine found a non-obvious move" beat the pitch needed. Baseline reproduces to the digit (₹50.3cr / 91.5% / W4 at 25%). `lockOpen` works correctly.

**But H1 introduced three regressions that are worse than the bug it fixed**, and the most damaging one is a UI problem: **the exited site is invisible on the canvas.** After converging, WH 4 renders identically to a candidate that was never opened — same grey dashed circle, same "+" suffix. The headline v6 feature cannot be seen in the demo. That's the single most important fix in this document.

Beyond that: 3 of 4 objective buttons now return the *identical* network, the balanced objective's discrimination has collapsed, a manual capacity drag silently corrupts the next optimiser run, and the documentation's engine spec (§5, §8, §9) still describes v5.

---

## 1. Did the v5 fixes actually land? (harness-verified)

| Fix | Status | Evidence from running the v6 engine |
|---|---|---|
| **H1** optimiser can exit active sites | ✅ **Works** | Cost objective returns `WH1,2,3,5,6,7` — **exits WH 4**, opens WH 6+7. ₹43.31cr vs ₹50.34cr baseline (−₹7.03cr), service 91.5→95.8%. 255 configs evaluated (2⁸−1). |
| **H1** `lockOpen` guard | ✅ **Works** | Locking W4 → forced open, evals halve to 128, optimum becomes ₹44.25cr. Correct constraint behaviour. |
| **H2** close-vs-shrink consistency | ⚠️ **Narrative only** | The *model* is unchanged (`fixedCost = Σ open fixedCost`; shrink still saves 0). Fixed by stating the lease assumption in `expNote` + watch-out. That's legitimate — it was option (a) in review #1 — but see **U7**, the wording misleads in practice. |
| **H3** service objective matches KPI | ✅ **Works** | Score is now `(1−serviceLevel)×1e4 + avgDistance`. Service-optimal hits 100.0% and does top the Compare service column. See **E3** for a tiebreak side-effect. |
| **H4** honest coverage matrix | ✅ **In §2** | Good matrix, correctly downgraded. But §5/§8/§9/§10 were not updated to match — see **D1**. |
| Right-sizing to convergence (bonus) | ✅ **Works** | 4-pass loop; even absurd 1-DC configs are right-sized to 5,900k and priced (+₹8.2cr), so no unpriced-infeasible config can win. |

---

## 2. 🔴 UI — the critical one

### U1. An optimiser-exited site is visually indistinguishable from an unopened candidate
`NetOptim_v6.jsx:795–812`. Node rendering branches only on `isOpen`:
```jsx
const col = isOpen ? utilColor(u) : "#3a3a3a";
strokeDasharray={isOpen ? "none" : "4 4"}
<text …>{w.name}{!isOpen && " +"}</text>
```
After "Converge to optimum" exits WH 4, it renders as a **grey dashed circle labelled "WH 4 +"** — pixel-identical to WH 8, a candidate that was never opened. Two problems:

1. **The demo's money shot is invisible.** You'll say "the optimiser recommends exiting WH 4" while the canvas shows nothing that reads as an exit. Judges watching a 2-minute video will not spot it.
2. **The "+" suffix is actively wrong.** On a site the optimiser just *closed*, "+" signals "click to add" — the opposite of what happened.

**Fix (highest ROI in this document, ~20 lines):** give closed-but-active sites their own encoding. Something like a red dashed ring, a strike-through label, and an "✕ EXITED" tag — versus candidates staying grey-dashed "+". Add both to the legend. Suggested:
```jsx
const wasActive = w.status === "active";
const col = isOpen ? utilColor(u) : wasActive ? "#F85149" : "#3a3a3a";
// label suffix: isOpen ? "" : wasActive ? " ✕" : " +"
```

### U2. `lockOpen` is invisible everywhere except inside the editor
The flag is only settable and only visible in the DC editor panel (`:847–850`). It appears in:
- ❌ the map node rendering (`:795–812` never reads `w.lockOpen`)
- ❌ the warehouse table (`:646` — no Lock column)
- ❌ the Compare tab
- ❌ anywhere near the "Converge to optimum" button

**Consequence:** a user locks two DCs, converges, gets a different answer, and has no on-screen reason why. During a live demo this is a "wait, why did it change?" moment with no recovery. **Fix:** a 🔒 glyph on locked map nodes, a lock column/pill in the table, and a `"2 locked"` chip beside the Converge button.

### U3. Lock is unavailable for candidate sites
The lock button lives inside the `selOpen ? … : …` open-branch (`:830–857`). A candidate can't be locked open — so you cannot express "this new DC is already board-approved, force it in." That's a real network-design constraint and a natural judge question. Cheap to add to the candidate branch.

---

## 3. 🟠 UI — high priority

### U4. Editor panel has no height constraint, and v6 made it taller
`S.editor` (`:1224`) is `position:absolute; top:52; left:16; width:256` with **no `maxHeight` and no `overflowY`**. The open-DC editor now stacks: 4 rows + capacity slider + the **much longer H2 `expNote`** (~200 chars, ~9 wrapped lines at 11px/228px) + Close button + **new Lock button** (whose label "🔒 Locked open — optimiser can't close this DC" wraps to 2 lines at that width).

Estimated height ≈ 440–470px, starting at y=52. On a 1080p desktop that's fine. On a **1280×720 projector** the map is ~587px tall, so the panel bottom lands ~500px — clearing the legend (`bottom:12`) by well under 80px, and any longer wrap collides. **Fix:** `maxHeight: "calc(100% - 80px)", overflowY: "auto"` on `S.editor`. One line, removes the whole class of risk.

### U5. Capacity slider is still hardcoded 600–3000 (unfixed M2 from review #1)
`:837` — `min={600} max={3000}`. Two visible failures now, both reachable in v6:
- Upload a DC with capacity 5,000 → selecting it shows the thumb pinned at max while the label reads "5,000k". Touching the slider **silently shrinks the site to 3,000**.
- The optimiser right-sizes aggressively (a 1-DC config goes to 5,900k). Load that scenario, click the DC → same mismatch.

**Fix:** `min={Math.round(selWh.capacity*0.5/50)*50}`, `max={Math.max(3000, Math.ceil(selCap*1.25/50)*50)}`.

### U6. Compare tab bar labels truncate exactly where the new information is
`S.barName` is a fixed `220px` column with `textOverflow: ellipsis` (`:1197–1198`). v6's `configName` (`:297–302`) now appends closures, so names grew:
> `S3 · opt-cost · open WH 6+WH 7, close WH 4`

At 220px / 12px font (~34 chars) that clips to roughly `S3 · opt-cost · open WH 6+WH…` — **the closure, the v6 headline, is the part that gets cut.** Fix: widen to 300–320px, or reorder `configName` to put closures first, or add a `title` attribute for hover.

### U7. The H2 lease note is technically true but misleads on screen
`:845` tells the user *"In-lease shrink below base saves nothing (lease committed)."* Harness-verified what actually happens when you drag W2 down:

| W2 capacity | Fixed cost | Total cost | Service |
|---|---|---|---|
| 2,200k (base) | ₹18.90cr | ₹50.34cr | 91.5% |
| 1,400k | ₹18.90cr | ₹50.51cr (**+0.17**) | 90.7% |
| 1,000k | ₹18.90cr | ₹52.13cr (**+1.79**) | 83.9% |
| 600k | ₹18.90cr | ₹55.96cr (**+5.62**) | 77.1% |

Fixed cost is flat as promised — but **total cost rises** because displaced volume reroutes to costlier lanes. A user reading "saves nothing" then watching the number climb will think the tool is broken. **Fix the wording:** *"Shrinking saves no fixed cost (lease committed) and pushes volume to other DCs — expect freight and service to worsen."*

Related: `expNote` only renders when `selExpCost === 0` (`:843–845`). The moment the user expands, `expWarn` replaces it and **the entire H2 lease assumption disappears from the UI** — precisely while they're manipulating capacity. Put the lease line somewhere permanent.

### U8. Carbon KPI cell overflows on projector-width screens
`S.kpiBar` is `repeat(5,1fr)` (`:1269`). The carbon cell (`:920–924`) packs a `whiteSpace:"nowrap"` label — `tax ₹2000/t (₹19.9cr)` ≈ 130px — plus gap plus a slider with `minWidth:50`. That needs ~187px inside a cell that has 32px of padding.
- 1280px wide → 224px available ✅
- **1024px wide → 172px available ❌ overflow/clip**

1024×768 is a very common projector mode. **Fix:** drop `whiteSpace:"nowrap"`, or move the slider to its own row inside the cell, or `gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))"`.

### U9. No progress state on "Converge to optimum" — and v6 made it 32× slower
H1 expanded the search from 8 configs to 255. Measured runtimes (synchronous, main thread, no spinner):

| Network | Configs | Time | UI |
|---|---|---|---|
| Seed 8 WH / 13 D | 255 | **104 ms** | fine |
| 10 WH / 20 D | 1,023 | 131 ms | fine |
| 12 WH / 30 D | 4,095 | **763 ms** | noticeable |
| 13 WH / 40 D | 4,096 | **1,069 ms** | ❄️ frozen tab |
| 14 WH / 50 D | 4,096 | **1,538 ms** | ❄️ frozen tab |

The seed demo is safe. But if a judge uploads their own CSV — which the Setup tab actively invites — the button dead-freezes with zero feedback. **Fix:** a `busy` state on the button (`Converging… n/255`) plus a `setTimeout(…, 0)` yield before the loop, so the label paints. A Web Worker is the production answer.

### U10. Sites beyond the 12-site enumeration cap are silently forced open
`:145–149` — `enumIds = nonLocked.slice(0, 12)`, everything past index 12 goes into `forcedOpen`. On a 14-site upload, **two arbitrary sites (whichever land last in array order) are never considered for closure**, and nothing in the UI says so. The recommendation is quietly constrained. **Fix:** surface it — *"14 sites: closure search limited to the first 12; 2 held open."* Better: pick the 12 by a heuristic (lowest utilisation first) rather than array order.

---

## 4. 🟡 Engine findings that surface as UI problems

*(Flagging briefly since you asked to go light on deep accuracy — but these three are visible on screen during the demo.)*

### E1. Three of four objective buttons return the identical network
| Objective | Result | Cost | Service |
|---|---|---|---|
| Cost | `W1,2,3,5,6,7` — **exits W4** | ₹43.31cr | 95.8% |
| Service | `all 8 open` | ₹45.43cr | 100.0% |
| Balanced | `all 8 open` | ₹45.43cr | 100.0% |
| Carbon | `all 8 open` | ₹45.43cr | 100.0% |

Clicking Service, Balanced, or Carbon produces the **same map, same KPI bar, same everything**. Docs §5 still advertises "distinct answers per objective" — that was v5 behaviour and is no longer true. On stage, three of your four objective buttons look broken.

Root cause: **carbon score ignores cost entirely** (`:187`, `score = e.carbon`), and carbon is monotonically decreasing in site count (verified: 8 DCs = 103.5k tCO₂ < every 7-DC config < every 6-DC config). So "carbon-optimal" is always "open literally everything" — economically absurd and trivially uninteresting. **Fix:** score carbon as `totalCost` with carbon priced in, or minimise carbon subject to cost ≤ baseline.

### E2. Balanced objective's discrimination has collapsed (H1 side-effect)
`balanced` uses min-max normalisation across all evaluated configs (`:180–188`). H1 admitted 1-DC networks into the eval set, blowing the range out:

| | Configs | Cost range | Distance range |
|---|---|---|---|
| v5-style (actives always open) | 8 | ₹44.2–51.5cr | 195–374 km |
| **v6 full enumeration** | 255 | **₹43.3–160.3cr** | **195–1,835 km** |

Realistic configs now occupy **6.2% of the cost range and 10.9% of the distance range**. Every sensible option scores between 0.009 and 0.018 — the top four are separated by 0.004. **90% of the 255 evaluated configs are dominated by the baseline on both cost and service.** The balanced trade-off has become noise. **Fix:** normalise only over the non-dominated (Pareto) set, or over configs within some band of baseline.

### E3. Service tiebreak pays ₹1.18cr/yr for zero service gain
Two configs reach exactly 100.0% service. H3's tiebreak is `avgDistance`, so it picks the 8-DC config (195 km, ₹45.43cr) over the 7-DC config (225 km, **₹44.25cr**). Once the service *promise* is met, spending ₹1.18cr to shave average haul is hard to defend to a judge. **Fix:** tiebreak on cost instead of distance — `(1−serviceLevel)×1e4 + totalCost`.

### E4. 🔴 A manual capacity drag silently corrupts the next optimiser run
`:160` — `let cap = { ...(capOverride || {}) };` seeds **every** evaluated config with the user's manual overrides, and right-sizing only ever expands. The optimiser therefore **never considers reverting a manual expansion.**

Verified: set W3 → 3,000k by slider, then Converge for cost. Result reports ₹46.31cr as "optimal" — carrying a ₹3.00cr expansion penalty into all 255 configs. The true optimum is ₹43.31cr. **The tool confidently reports a number ₹3cr worse than optimal with no warning.**

This is a live demo hazard: the capacity slider auto-logs on release, so a presenter fiddling with it and then hitting Converge gets a wrong answer on screen. **Fix:** start the optimiser from `{}` and treat capacity purely as a decision variable, or add a visible "optimising with your manual overrides locked in — clear them?" prompt.

---

## 5. 🟢 UI — lower priority polish

- **U11.** The Lock button reuses `S.dangerBtn` (red) as its base with overrides. Unlocked it renders grey-on-transparent directly under a red "Close this DC" — reads as disabled. Give it its own neutral style.
- **U12.** `doReset` (`:436`) clears `openIds` / `capOverride` but **not `lockOpen` flags**, while the message says "Reset to current-state baseline." Locks silently persist into the next converge. Either clear them or say so.
- **U13.** `objective` is one shared state between the Simulator's optimise target and the Compare tab's "winner scored on" selector (`:956`). Changing it in Compare silently changes what the next Converge optimises for.
- **U14.** Utilisation "<50%" cyan `#2FB8D6` is the exact same hex as the cheap end of the flow-cost gradient (`:209`, `:205`). A low-utilisation node and a cheap lane are the same colour.
- **U15.** Still no keyboard/ARIA on SVG nodes (unfixed L2 from review #1) — `<g onClick>` with no `role`, `tabIndex`, or `aria-label`.
- **U16.** Legend (`:815–819`) documents cyan/green/amber/red utilisation and line encodings but not: candidate vs exited, locked, or the dashed "overflow" line style.
- **U17.** Demand slider still uses the revert-then-`setTimeout(0)`-reapply trick (`:874–875`) to capture before/after; on touch devices `onMouseUp` and `onTouchEnd` can both fire, applying twice.
- **U18.** Compare table is 11 columns in an `overflowX:auto` wrapper; the Load/delete actions are the **last** column, so on a 1280px screen they're off-screen until you scroll right.
- **U19.** `newProblem` / `loadSample` still don't reset `objective`, `flowMetric`, or `laneView` (unfixed L4).

---

## 6. 📄 Documentation drift — v6 doc is internally contradictory

`NetOptim_Project_Documentation_v6.md` §2 was updated beautifully. **Nothing else was.**

| Location | Says | Reality |
|---|---|---|
| Header line 2 | "**Prototype version: v5**" | It's the v6 doc |
| §4 heading | "single file `NetOptim.jsx`" | File is `NetOptim_v6.jsx` |
| §5 Optimiser | "enumerates every open/close subset of **candidate** sites (≤10) **on top of active sites**" | ❌ This is the exact v5 behaviour H1 removed |
| §5 Optimiser | "service = **avg distance**" | ❌ H3 changed this to on-time share |
| §5 Verified numbers | "optimise-cost → open W6+W7 (₹~44cr)" | ❌ Now W6+W7 **and exit W4**, ₹43.31cr |
| §5 Verified numbers | "Distinct answers per objective" | ❌ 3 of 4 objectives now identical (E1) |
| §8 Version history | no v6 row | v6 undocumented |
| §9 Limitations | "enumerative over ≤10 candidates" | Now ≤12 over all sites |
| §10 | "₹5.9cr/yr saving" | Cost-optimal is now **₹7.03cr** — you're under-selling by ₹1.1cr |

A judge who reads §5 gets the **old engine spec** while §2 claims the new one. Worse, §10's value headline is now *too low* — H1 improved the saving from ₹5.85cr to ₹7.03cr (14% of baseline, not 12%). **Update §5, §8, §9, §10 and the header; the new headline number is a free win.**

---

## 7. Prioritised fix list

**🔴 Must fix before recording the video (≈2 hrs total):**
1. **U1** — distinct visual for an exited site. *Without this the H1 fix is invisible in your demo.*
2. **E4** — don't seed the optimiser from manual `capOverride` (silent ₹3cr wrong answer, live-demo reachable).
3. **E1** — make carbon cost-aware so Service/Balanced/Carbon stop returning identical networks.
4. **D1** — reconcile docs §5/§8/§9/§10; update the value headline to **₹7.03cr (14%)**.

**🟠 Should fix (≈1 hr):**
5. **U4** — `maxHeight` + `overflowY` on the editor panel.
6. **U9** — busy state on Converge.
7. **U2** — surface `lockOpen` on the map + table.
8. **U7** — reword the shrink note; keep the lease assumption permanently visible.
9. **U8** — carbon KPI cell responsive fix (projector safety).

**🟡 If time:**
10. **E2** normalise balanced over the Pareto set · **E3** tiebreak on cost · **U5** data-driven slider bounds · **U6** widen Compare labels · **U10** warn on the 12-site cap · **U3** lock candidates · U11–U19 polish.

---

## 8. Demo risk register (things that can bite you live)

| Risk | Trigger | Mitigation until fixed |
|---|---|---|
| Exit is invisible | Converge for cost | Narrate it explicitly and click WH 4 to show the editor; fix U1 |
| Wrong "optimal" number | Drag a capacity slider, then Converge | Never touch capacity before converging; hit Reset first |
| Three objectives look broken | Clicking through Service/Balanced/Carbon | Demo Cost and one other only, until E1 is fixed |
| Tab freezes | Judge uploads a 13+ site CSV | Keep uploads to the seed size during Q&A |
| Panel overflows | Selecting a DC on a 720p projector | Test on the actual projector; fix U4 |

---

## 9. What genuinely improved — say this in the deck

- The optimiser now answers the brief's actual question (*"resize or **exit** existing sites"*) and finds the WH 4 exit **without being told**. That is a much stronger stage moment than v5's "open a candidate."
- The saving improved from **₹5.85cr → ₹7.03cr/yr (~14% of a ₹50.3cr baseline)** with service simultaneously up **+4.3 pts** — cost *and* service improving together, driven by a machine-found closure.
- `lockOpen` is a genuinely consultant-grade touch: it encodes "this DC can't leave its lease" as a *constraint on the search*, which is exactly the objection a Kearney partner would raise. Make sure it's visible (U2) so you can demo it.
- Right-sizing to convergence means no recommended configuration is silently infeasible — worth one line on Slide 2 under assumptions.

---

*Engine claims verified by executing the v6 logic verbatim in Node (255-config enumeration, baseline ₹50.34cr / 91.5% / W4 25% reproduced exactly). UI findings are code-read against layout constants; the projector-width and panel-overflow items are estimates from the style values and should be confirmed on the actual presentation display.*

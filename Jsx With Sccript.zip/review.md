# NetOptim v5 — Reviewer's Report
**Scope:** `NetOptim.jsx` (engine + UI) and `NetOptim_Project_Documentation.md`, reviewed against **Case 16 — Interactive Logistics Network Optimisation Agent** (KOSMIC / Kearney).
**Reviewer stance:** consultant + engineer sanity-checking the prototype before Round‑1 slides are built.

---

## 0. Verdict (TL;DR)

Strong prototype. The three‑layer story (Visualise → Simulate → Reason) is clean, the engine is mostly self‑consistent, the "open WH 6 improves cost **and** service" hero moment is a genuine demo asset, and the honest‑AI framing is exactly right for judges.

But there are a **handful of defensibility gaps a sharp judge will find in 90 seconds** — chiefly that the optimiser can't do the one thing the brief explicitly asks (exit an existing site), an internal cost inconsistency between "close" and "shrink," and a documentation file that claims 100% case coverage when 3–4 sub‑requirements are only partial or missing. None are hard to fix; most are 1–2 hours of work. Fixing the "Critical/High" list below is the difference between a slick demo and a bullet‑proof one.

---

## 1. What's strong (keep, and lean on it)

- **Cheapest‑lane‑first (matrix‑minimum) assignment** is the right call and the v1→v4 history (fixing irrational cross‑hauls) is a great story to tell if asked "how do you route?".
- **Cost model is unit‑consistent.** Freight, handling (`vol×opex/1e4`), expansion (`Δcap×0.002`), and carbon (`k tCO₂ × price/1e4`) all reconcile to ₹cr/yr correctly. I checked the unit algebra on each term.
- **Baseline semantics are principled** — baseline = active sites, no overrides, *current data* — so deltas isolate network decisions, and demand changes get their own before→after card. This is a subtle, correct design choice; call it out to judges.
- **Auto‑logging every tested config to Compare** (dedup by signature) is a real differentiator vs a classic solver and supports the "robustness" narrative.
- **Honest framing** (rule‑based parser as LLM stand‑in; mic visual‑only) converts weaknesses into credibility. Do keep saying it proactively.
- **Guardrails against NaN** are mostly in place (`Math.max(1, …)` on denominators, `capOf>0 ? … : 0`, `|| 0` on throughput).
- **Regex name‑matching with word boundaries** correctly avoids the "D1 matches D12 / WH 1 matches WH 12" trap. Nicely done.

---

## 2. Critical / High — fix before you demo or submit

### H1. The optimiser cannot close or exit an active site — contradicts the brief and your own WH 4 story
In `optimize()`:
```js
const open = [...activeIds, ...candIds.filter((_, i) => m & (1 << i))];
```
Active sites (WH 1–5) are **always** in the open set; only *candidate* subsets are enumerated. So "Converge to optimum" will never recommend closing WH 4 — even though your seed narrative flags WH 4 as ~25% utilised and the case brief explicitly lists the decision as *"whether to resize or **exit** existing sites."* If a judge asks "what does your optimiser say about the under‑used site?", the honest answer today is "it won't touch it."
**Fix:** enumerate open/close over *all* non‑locked sites, not just candidates. Add a per‑site `lockOpen` flag (some DCs genuinely can't close mid‑lease) so you can still constrain it, but the default search space should include closures. This also makes the WH 4 exit a *machine‑found* recommendation instead of a manual click — much stronger on stage.

### H2. Inconsistent fixed‑cost logic: closing saves 100%, shrinking saves 0%
- `fixedCost = Σ openIds.fixedCost` → closing a site removes its **entire** fixed cost.
- The capacity editor's `expNote` says shrinking below base *"doesn't save (lease committed)."*

Both can't be true. If the lease is a sunk commitment, a full closure shouldn't zero the fixed cost either (at least not until a break clause). Right now shrink = sunk, close = fully avoidable.
**Fix (pick one and state it):** (a) treat fixed cost as avoidable on closure only at lease break/renewal and surface that assumption, or (b) split fixed cost into an avoidable vs committed portion. Even a one‑line explicit assumption ("closure modelled at lease exit; in‑lease shrink saves nothing") resolves it and is defensible.

### H3. "Optimise for service" minimises average distance, but the KPI you *show* is service‑% within threshold
- Optimiser score for `service` = `avgDistance` (lower is better).
- Compare tab + KPI bar report **service level = share of demand within 700 km**.

These usually correlate but not always: a config can have lower avg distance yet a worse tail (more demand *just* over the threshold). A judge could point at the Compare table and say "your service‑optimal scenario doesn't have the highest service %." — and be right.
**Fix:** either optimise directly on service‑% (maximise on‑time share) so the objective matches the displayed metric, or relabel the objective "shortest average haul" and note the distinction. Aligning them is cleaner.

### H4. Documentation over‑claims full Case‑16 coverage
`Documentation.md` §2 says *"All of the above are implemented."* Several sub‑requirements are only **partial or missing** (detail in the coverage matrix, §5). A reviewer/judge who reads the case checklist and then your deck will notice. Under‑claim and over‑deliver, not the reverse.
**Fix:** downgrade §2 to an honest coverage matrix (implemented / partial / roadmap). It costs you nothing and buys credibility.

---

## 3. Medium — should fix, or at least name as explicit assumptions

- **M1. Compare tab only captures *topology* scenarios, not demand/carbon what‑ifs.** `autoLog` signatures are `{open set, capacity overrides}` only. Demand changes mutate the global `customers` array and carbon price is global, so *all* Compare rows re‑solve under the *current* demand/carbon, live. Consequence: you cannot hold "baseline demand" and "D9 +30%" side‑by‑side as two rows — changing demand shifts every row at once. This matters for your video script ("increase D9 30% → converge → compare"): the Compare tab will show configs under the *new* demand, not both worlds. **Fix:** snapshot `demandMult`/per‑region demand and `carbonPrice` into each logged scenario so demand shocks become first‑class comparables.

- **M2. Capacity slider bounds are hardcoded 600–3000.** An uploaded site with capacity >3000 (or <600) can't be represented; dragging would silently shrink it to 3000. **Fix:** derive slider min/max from the site's own capacity (e.g. `[0.5×base, 2.5×base]`).

- **M3. Calibration is anchored to seed geometry.** `RATE_CR` is computed once at module load from `SEED_*` so that seed freight = ₹30cr. The *rate* is legitimately reusable, but the "₹30cr baseline" anchor only holds for the seed network — uploaded networks get sensible relative numbers but an arbitrary absolute scale. The doc frames ₹30cr as a property of the tool; it's a property of the seed. **Fix:** recalibrate on data load (re‑run the pure‑distance pass against whatever data is active), or state clearly that absolute ₹ are illustrative and only *relative* deltas are meaningful for uploads.

- **M4. Right‑sizing is single‑pass.** In `optimize`, overloaded sites are expanded once; because expansion changes capacity it reshuffles the assignment, which can push a *different* site over 100%. The expanded variant may still contain residual overloads. **Fix:** iterate right‑sizing to convergence (2–3 passes is plenty), or note it as a known heuristic bound.

- **M5. Enumeration runs synchronously on the main thread.** Up to `2^10` candidate subsets × (base + right‑sized) KPI solves, each iterating `|WH|×|D|` lanes. Fine for seed (8×13). A large upload (many customers, 10 candidates) can freeze the tab with no spinner and no row cap. **Fix:** cap candidate count in UI with a warning, add a progress state, and/or move `optimize` to a Web Worker for production.

- **M6. Carbon *factor* is hidden and not stress‑tested.** `EMISSION_FACTOR` and `SCALE_KM` aren't shown in the parameter cards or editable, yet carbon output depends entirely on the factor. The sensitivity tab varies carbon *price* but not the *emission factor* — and the case explicitly lists **"carbon factors"** under sensitivity. **Fix:** surface the emission factor in the param cards and add a factor slider (or at least a note) to the sensitivity panel.

- **M7. CSV download reliability unverified in the artifact sandbox.** `downloadCsv` uses `URL.createObjectURL` + anchor click. Some sandboxes block downloads (same class of limitation as the mic). **Fix:** test in the target render surface; if blocked, fall back to copy‑to‑clipboard or an inline textarea.

---

## 4. Low / polish

- **L1. Red/green + amber utilisation encoding** is a colour‑blindness risk. The util‑% text on nodes partly mitigates it; consider adding shape/hatch or a text tag for over‑capacity.
- **L2. Map nodes aren't keyboard/ARIA accessible** — clicks only, no focus/`role`/`aria-label` on the `<g>` groups. Fine for a demo; flag for production.
- **L3. Reset semantics vs messaging.** `doReset` keeps `carbonPrice`, `laneMult`, and `scenarios`, but the copilot says "Reset to current‑state baseline," which reads as a full reset. Reword to "Reset network to baseline (assumptions unchanged)."
- **L4. `newProblem` / `loadSample` don't reset `objective`, `flowMetric`, or `laneView`.** Minor state bleed between problems.
- **L5. Value‑claim wording collision.** §10 cites "₹5.9cr/yr saving" while §5 verifies the WH 6 saving as **−₹5.85cr**; and 5.9 dangerously echoes the "5.9M units/yr" figure. Use "≈₹5.85cr (~12% of the ₹50.3cr baseline)" to avoid the coincidental clash.
- **L6. `inr()` on negatives** renders "₹-5.9cr" (sign inside). Deltas are handled separately so it's cosmetic, but worth a tidy.
- **L7. Single 1000‑line file, no shipped tests, no types.** Acceptable for an artifact; for production, extract the engine to its own module, add the node harness referenced in §5/§11 to the repo (it isn't in the file, so its claims can't be verified by a reviewer), and move to TypeScript.

---

## 5. Case‑16 requirement coverage matrix (honest version)

| Case‑16 requirement | Status | Note |
|---|---|---|
| Current‑state visualisation (nodes, customers, flows, volumes, costs, service) | ✅ | Solid |
| Nodes sized by throughput / utilisation / capacity / cost / **role** | ⚠️ Partial | Sized by throughput, coloured by utilisation. Capacity/cost/**role** not used as visual encodings (type exists in data only). |
| Flow lines by volume / cost / distance / **mode** / **criticality** | ⚠️ Partial | Volume (thickness) + cost (colour) only. **Mode** and **service‑criticality** not implemented. |
| Identify corridors, over/under‑used nodes, long flows, cost hotspots | ✅ | Auto‑scan does this well |
| Scenario builder (move / consolidate / close / add / resize) | ⚠️ Partial | Add/close/resize ✅. "**Move**" a warehouse and explicit "consolidate" aren't first‑class actions (move = edit x/y in table). |
| Recalculate KPIs (cost, distance, service, reallocation, utilisation, carbon) | ✅ | All present |
| Side‑by‑side comparison vs baseline | ✅ | But topology‑only (see M1) |
| Sensitivity: transport cost, demand, service targets, **capacity**, **distance**, **carbon factors** | ⚠️ Partial | Rate, demand, service‑km, carbon **price** ✅. **Global capacity**, **distance/scale**, and carbon **factor** sliders missing. |
| Recommend optimal config with go/no‑go rationale | ⚠️ Partial | Strong rationale, **but optimiser can't close active sites** (H1) |
| Explain logic defensibly | ✅ | Good Why + Watch‑outs |
| Implementation considerations | ✅ | Present in cards + docs |
| Interactive map dashboard | ✅ | Yes |

**Bottom line:** ~7 fully met, ~5 partial, 0 that can't be reached — but the doc currently marks all 12 as done. Re‑stating this matrix on Slide 2 (as "shipped vs roadmap") is more persuasive than claiming completeness.

---

## 6. Competition‑framing notes

- **"Where's the AI?" is coming.** Your honest framing is good; strengthen it by naming the *agentic loop* explicitly on Slide 1: perceive (auto‑scan) → reason (NL what‑if) → act (re‑solve) → recommend (rationale + watch‑outs) → log. Position the enumerative optimiser + rule parser as a *deterministic stand‑in* for the production LLM‑plans‑solver‑calls agent. That reframes "it's rule‑based" from a weakness into "the reasoning contract is already defined."
- **Lead the demo with the hero moment** (open WH 6 → cost down *and* service up) — it's counter‑intuitive and memorable. But once H1 is fixed, add a second beat: "converge → the optimiser *also* recommends exiting WH 4," which closes the loop on the brief's "resize or exit" question and shows the machine finding a non‑obvious move.
- **Robustness beat:** the Compare sliders + ★‑stays‑put narrative is excellent. Just be careful (M1) that the demand‑shock scenario is framed as "re‑solved under new demand," not "two demand worlds compared."
- **Value line:** "≈₹5.85cr/yr (~12% of ₹50.3cr) + ~6.8 service pts; decision cycle weeks → minutes" is a clean, defensible headline once L5 wording is tidied.

---

## 7. Prioritised action list (maps to your Round‑1 "remaining work")

**Must‑do before submission (engine credibility):**
1. H1 — let the optimiser enumerate closures of active sites (+ optional `lockOpen`).
2. H2 — reconcile close‑vs‑shrink fixed‑cost logic; state the lease assumption.
3. H3 — align "service" objective with the displayed service‑% metric (or relabel).
4. H4 — replace "all implemented" with the §5 coverage matrix.

**High‑value polish (do if time):**
5. M1 — snapshot demand/carbon into logged scenarios (unlocks true demand‑shock comparison for the video).
6. M6 — surface + stress‑test the emission factor (closes the "carbon factors" sensitivity gap).
7. M2 — data‑derived capacity slider bounds (prevents an ugly bug if judges upload data).

**Nice‑to‑have:**
8. M3/M5 recalibration + worker; L1–L7 cosmetics; add the validation harness to the repo so §5's "verified" claims are inspectable.

**Slide/video (unchanged from your plan, with the above baked in):** Slide 1 = 3‑layer + agentic loop diagram; Slide 2 = coverage‑matrix + value + honest assumptions (H2 lease, H4 partials, heuristic‑vs‑MILP); video arc = scan → D9 +30% shock → converge (now including WH 4 exit) → Compare robustness → value line.

---

*Reviewed against the v5 source and documentation as provided. The node validation harness referenced in the docs was not included in the files, so §5's numeric claims were checked for unit‑consistency and logic but not re‑executed end‑to‑end — shipping that harness alongside the code would let a reviewer verify them directly.*
